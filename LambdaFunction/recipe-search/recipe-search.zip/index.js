const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

exports.handler = async (event) => {
    console.log("Event received:", JSON.stringify(event, null, 2)); 

    try {
        const corsHeaders = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'OPTIONS,POST',
            'Access-Control-Allow-Headers': 'Content-Type'
        };

        if (event.httpMethod === 'OPTIONS') {
            return {
                statusCode: 200,
                headers: corsHeaders
            };
        }

        // Parse the incoming request body or event
        let requestBody = event.body ? JSON.parse(event.body) : event;
        
        const entities = requestBody.entities || [];
        const cuisineType = requestBody.cuisineType || 'any';
        const foodType = requestBody.foodType || 'any';
        const nutritionGoals = requestBody.nutritionGoals || [];

        const spoonacularAPIKey = "e4beedd4bdad45219e223a6100e79276";

        // Start progressive search logic
        let recipes = [];
        for (let i = entities.length; i > 0; i--) {
            const querySubset = entities.slice(0, i).join(',');

            // Build the URL
            let spoonacularURL = `https://api.spoonacular.com/recipes/complexSearch?query=${querySubset}&apiKey=${spoonacularAPIKey}`;

            // Add optional filters for diet, cuisine, and nutrition goals
            if (foodType !== 'any') {
                spoonacularURL += `&diet=${foodType}`;
            }
            if (cuisineType !== 'any') {
                spoonacularURL += `&cuisine=${cuisineType}`;
            }
            if (nutritionGoals.length > 0) {
                spoonacularURL += `&minProtein=10`; // Example for handling 'high protein', extend as needed
            }

            console.log("Fetching recipes from Spoonacular with URL:", spoonacularURL);

            // Fetch the recipes from Spoonacular
            const spoonacularResponse = await fetch(spoonacularURL);
            const data = await spoonacularResponse.json();

            if (spoonacularResponse.ok && data.results && data.results.length > 0) {
                recipes = data.results;
                break; // Stop when recipes are found
            }
        }

        // Handle no results found
        if (recipes.length === 0) {
            return {
                statusCode: 404,
                headers: corsHeaders,
                body: JSON.stringify({
                    message: 'No recipes found for the given query.',
                }),
            };
        }

        // Return recipes to the user
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({
                message: 'Recipes retrieved successfully',
                recipes: recipes, // The array of recipe results
            }),
        };

    } catch (error) {
        console.error('Error processing request:', error);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
            },
            body: JSON.stringify({ error: 'Internal Server Error' }),
        };
    }
};
