const { LanguageServiceClient } = require('@google-cloud/language');

// Provide the path to the service account key JSON file
const client = new LanguageServiceClient({
    keyFilename: '/var/task/google-credentials.json'  // Path to key file in Lambda deployment package
});

exports.handler = async (event) => {
    try {
        // CORS headers for the response
        const corsHeaders = {
            'Access-Control-Allow-Origin': '*',  // Allow all origins
            'Access-Control-Allow-Methods': 'OPTIONS,POST',  // Allowed methods
            'Access-Control-Allow-Headers': 'Content-Type'  // Allowed headers
        };

        if (event.httpMethod === 'OPTIONS') {
            // Handle preflight request for CORS
            return {
                statusCode: 200,
                headers: corsHeaders
            };
        }

        // Parse the incoming request body
        const requestBody = JSON.parse(event.body);
        const query = requestBody.query || '';
        const avoidIngredients = requestBody.avoidIngredients || []; // Ingredients to avoid
        const cuisineType = requestBody.cuisineType || 'any'; // Cuisine type
        const foodType = requestBody.foodType || 'any'; // Dietary restrictions

        // Use the Google Cloud NLP API for processing the query
        const document = {
            content: query,
            type: 'PLAIN_TEXT',
        };
        
        // Analyze the input with the NLP API for ingredients and dish types
        const [result] = await client.analyzeEntities({ document });
        const entities = result.entities.map(entity => entity.name.toLowerCase());

        // Additional logic to refine extracted entities
        let dishType = '';
        let nutritionGoals = [];

        // Check for nutrition goals in the query (e.g., "high protein", "low sodium")
        const nutritionKeywords = ['high protein', 'low fat', 'low sodium', 'high fiber'];
        nutritionKeywords.forEach(keyword => {
            if (query.toLowerCase().includes(keyword)) {
                nutritionGoals.push(keyword);
            }
        });

        // Example: If "curry" is part of the entities, consider it a dish type
        if (entities.includes('curry')) {
            dishType = 'curry';
        }

        // Filter out ingredients to avoid from the entities
        const filteredEntities = entities.filter(entity => !avoidIngredients.includes(entity));

        // Prepare the output with the extracted data
        const extractedData = {
            dishType: dishType || 'any',  // If no dish type is found, default to 'any'
            ingredients: filteredEntities, // Ingredients list without the avoided ones
            nutritionGoals: nutritionGoals.length > 0 ? nutritionGoals : 'none',  // Default to 'none'
            cuisineType: cuisineType,
            foodType: foodType
        };

        // Return the result with CORS headers
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({
                message: 'Processed query successfully',
                extractedData: extractedData,
            }),
        };

    } catch (error) {
        console.error('Error processing request:', error);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',  // CORS header for error response
            },
            body: JSON.stringify({ error: 'Internal Server Error' }),
        };
    }
};
